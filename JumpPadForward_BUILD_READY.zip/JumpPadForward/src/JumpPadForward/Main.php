<?php

declare(strict_types=1);

namespace JumpPadForward;

use pocketmine\plugin\PluginBase;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\math\Vector3;
use pocketmine\block\VanillaBlocks;

class Main extends PluginBase implements Listener{

    private array $cooldowns = [];

    public function onEnable() : void{
        $this->saveDefaultConfig();
        $this->getServer()->getPluginManager()->registerEvents($this, $this);
    }

    public function onMove(PlayerMoveEvent $event) : void{
        $player = $event->getPlayer();

        if(!$player->isOnGround()){
            return;
        }

        $pos = $player->getPosition()->floor();
        $world = $player->getWorld();

        $block = $world->getBlock($pos->subtract(0, 2, 0));

        if(!$this->isPadBlock($block)){
            return;
        }

        $name = $player->getName();
        $now = microtime(true);

        $cooldown = (float)$this->getConfig()->get("cooldown", 0.7);

        if(isset($this->cooldowns[$name]) && ($now - $this->cooldowns[$name]) < $cooldown){
            return;
        }

        $this->cooldowns[$name] = $now;

        $direction = $player->getDirectionVector();

        $power = (float)$this->getConfig()->get("power", 2.5);
        $yBoost = (float)$this->getConfig()->get("y-boost", 1.3);

        $player->setMotion(new Vector3(
            $direction->x * $power,
            $yBoost,
            $direction->z * $power
        ));
    }

    private function isPadBlock($block) : bool{
        $type = strtolower((string)$this->getConfig()->get("pad-block", "slime"));

        return match($type){
            "slime" => $block->equals(VanillaBlocks::SLIME()),
            "gold" => $block->equals(VanillaBlocks::GOLD_BLOCK()),
            "emerald" => $block->equals(VanillaBlocks::EMERALD_BLOCK()),
            "diamond" => $block->equals(VanillaBlocks::DIAMOND_BLOCK()),
            "iron" => $block->equals(VanillaBlocks::IRON_BLOCK()),
            default => false
        };
    }
}
