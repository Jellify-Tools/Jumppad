<?php

$pharFile = "JumpPadForward.phar";

if(file_exists($pharFile)){
    unlink($pharFile);
}

$phar = new Phar($pharFile);
$phar->buildFromDirectory(__DIR__);
$phar->setStub($phar->createDefaultStub("src/JumpPadForward/Main.php"));

echo "PHAR built successfully!\n";
